import {Header} from "./components/Header";    
import {Post} from "./Post";
import styles from "./App.module.css"
import './global.css';

export function App(){
  return (

    <div>
      <Header/>
    <div className={styles.wrapper}>
      <aside>
        Sidebar
      </aside>
       <main>
          <Post
          author="Machado de assis"
          coment="Lorem ipsum dolor sit amet consectetur adipisicing elit."/>
      <Post
          author="Castro Alves"
          coment="Lorem ipsum dolor sit amet consectetur adipisicing elit."/>
      <Post
          author="Padre Antonio Vieira"
          coment="Lorem ipsum dolor sit amet consectetur adipisicing elit."/>
      </main>
    </div>
 </div>
  )
}

