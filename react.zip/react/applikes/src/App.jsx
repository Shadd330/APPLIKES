import Post from "./Post"
function App() {
  return (
   <Post/>
  )
}

export default App
