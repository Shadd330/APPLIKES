function Post(){
    return<p>Post</p>
}

export default Post;